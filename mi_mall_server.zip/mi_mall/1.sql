SET NAMES UTF8;
DROP DATABASE IF EXISTS mi_mall;
CREATE DATABASE mi_mall CHARSET=utf8;
use mi_mall;

CREATE TABLE mi_category(
    iid INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(32),
    img_url VARCHAR(128),
    url VARCHAR(128),
    cid INT
);

INSERT INTO mi_category VALUES(NULL, '小米8 青春版', 'http://127.0.0.1:3000/imgs/qingchun-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米8 屏幕指纹版', 'http://127.0.0.1:3000/imgs/pingmu-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米8', 'http://127.0.0.1:3000/imgs/m8-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米8 SE', 'http://127.0.0.1:3000/imgs/m8se-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米MIX 2S', 'http://127.0.0.1:3000/imgs/mix2s80-80white.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米Max 3', 'http://127.0.0.1:3000/imgs/max3-80-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米6X', 'http://127.0.0.1:3000/imgs/80808080808080.jpg', '#', 1);
INSERT INTO mi_category VALUES(NULL, '黑鲨游戏手机', 'http://127.0.0.1:3000/imgs/heisha-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米MIX 2', 'http://127.0.0.1:3000/imgs/mix2-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米Max 2', 'http://127.0.0.1:3000/imgs/max2_80.jpg', '#', 1);
INSERT INTO mi_category VALUES(NULL, '红米6 Pro', 'http://127.0.0.1:3000/imgs/6pro140-140.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '红米', 'http://127.0.0.1:3000/imgs/666666.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '红米6A', 'http://127.0.0.1:3000/imgs/6AAAA.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '红米Note 5', 'http://127.0.0.1:3000/imgs/note5-80-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '红米S2', 'http://127.0.0.1:3000/imgs/s2-80-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '移动4G+专区', 'http://127.0.0.1:3000/imgs/80.jpg', '#', 1);
INSERT INTO mi_category VALUES(NULL, '对比手机', 'http://127.0.0.1:3000/imgs/compare.jpg', '#', 1);
INSERT INTO mi_category VALUES(NULL, '米粉卡 日租卡', 'http://127.0.0.1:3000/imgs/mifenka-1.jpg', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米移动 电话卡', 'http://127.0.0.1:3000/imgs/mimobile.jpg', '#', 1);
INSERT INTO mi_category VALUES(NULL, '手机上门维修', 'http://127.0.0.1:3000/imgs/weixiu80-80.png', '#', 1);

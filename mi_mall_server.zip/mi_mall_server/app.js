const express = require("express");
const cors = require("cors");

var category = require('./routes/category');

var app = express();
var server = app.listen(3000);

app.use(cors({
  origin:'http://localhost:8080', //请求来源地址
  credentials:true //要求携带cookie
}))


app.use(express.static(__dirname+"/static"));

app.use('/category', category);

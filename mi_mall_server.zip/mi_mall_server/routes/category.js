const express = require("express");
var router = express.Router();
var pool = require('../pool');

router.get('/list', (req, res)=>{
  var $cid = req.query.cid;
  var sql = "SELECT * FROM `mi_category` WHERE cid=?"

  pool.query(sql, [$cid], (err, result)=>{
    if(err){
      throw err;
    }
    res.send({code:1, msg:result});
  })
});

module.exports = router;

SET NAMES UTF8;
DROP DATABASE IF EXISTS mi_mall;
CREATE DATABASE mi_mall CHARSET=utf8;
use mi_mall;

CREATE TABLE mi_category(
    iid INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(32),
    img_url VARCHAR(128),
    url VARCHAR(128),
    cid INT
);

INSERT INTO mi_category VALUES(NULL, '小米8 青春版', 'http://127.0.0.1:3000/imgs/qingchun-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米8 屏幕指纹版', 'http://127.0.0.1:3000/imgs/pingmu-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米8', 'http://127.0.0.1:3000/imgs/m8-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米8 SE', 'http://127.0.0.1:3000/imgs/m8se-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米MIX 2S', 'http://127.0.0.1:3000/imgs/mix2s80-80white.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米Max 3', 'http://127.0.0.1:3000/imgs/max3-80-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米6X', 'http://127.0.0.1:3000/imgs/80808080808080.jpg', '#', 1);
INSERT INTO mi_category VALUES(NULL, '黑鲨游戏手机', 'http://127.0.0.1:3000/imgs/heisha-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米MIX 2', 'http://127.0.0.1:3000/imgs/mix2-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米Max 2', 'http://127.0.0.1:3000/imgs/max2_80.jpg', '#', 1);
INSERT INTO mi_category VALUES(NULL, '红米6 Pro', 'http://127.0.0.1:3000/imgs/6pro140-140.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '红米', 'http://127.0.0.1:3000/imgs/666666.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '红米6A', 'http://127.0.0.1:3000/imgs/6AAAA.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '红米Note 5', 'http://127.0.0.1:3000/imgs/note5-80-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '红米S2', 'http://127.0.0.1:3000/imgs/s2-80-80.png', '#', 1);
INSERT INTO mi_category VALUES(NULL, '移动4G+专区', 'http://127.0.0.1:3000/imgs/80.jpg', '#', 1);
INSERT INTO mi_category VALUES(NULL, '对比手机', 'http://127.0.0.1:3000/imgs/compare.jpg', '#', 1);
INSERT INTO mi_category VALUES(NULL, '米粉卡 日租卡', 'http://127.0.0.1:3000/imgs/mifenka-1.jpg', '#', 1);
INSERT INTO mi_category VALUES(NULL, '小米移动 电话卡', 'http://127.0.0.1:3000/imgs/mimobile.jpg', '#', 1);
INSERT INTO mi_category VALUES(NULL, '手机上门维修', 'http://127.0.0.1:3000/imgs/weixiu80-80.png', '#', 1);

INSERT INTO mi_category VALUES(NULL, '小米激光投影电视', 'http://127.0.0.1:3000/imgs/14000000000.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4 75英寸', 'http://127.0.0.1:3000/imgs/TV4-75.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4A 32英寸', 'http://127.0.0.1:3000/imgs/TV4A-32.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4A 40英寸', 'http://127.0.0.1:3000/imgs/TV4A-40.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4A 43英寸青春版', 'http://127.0.0.1:3000/imgs/TV4A-43QC.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4A 49英寸', 'http://127.0.0.1:3000/imgs/TV4A-49.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4A 50英寸', 'http://127.0.0.1:3000/imgs/TV4A-50.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4A 55英寸', 'http://127.0.0.1:3000/imgs/55120120.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4A 65英寸', 'http://127.0.0.1:3000/imgs/65120_120.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4X 55英寸', 'http://127.0.0.1:3000/imgs/TV4X-55.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4C 32英寸', 'http://127.0.0.1:3000/imgs/TV4C-32.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4C 43英寸', 'http://127.0.0.1:3000/imgs/TV4C-43.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4C 50英寸', 'http://127.0.0.1:3000/imgs/TV4C-50.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4C 55英寸', 'http://127.0.0.1:3000/imgs/TV4C-55.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视 体育版', 'http://127.0.0.1:3000/imgs/TVTYB.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4 55英寸', 'http://127.0.0.1:3000/imgs/TV4-55.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4 65英寸', 'http://127.0.0.1:3000/imgs/TV4-65.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4S 55英寸曲面', 'http://127.0.0.1:3000/imgs/TV4S-55Q.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4S 55英寸', 'http://127.0.0.1:3000/imgs/TV4S-55.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4S 50英寸', 'http://127.0.0.1:3000/imgs/TV4S-50.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4S 43英寸', 'http://127.0.0.1:3000/imgs/TV4S-43.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米电视4S 32英寸', 'http://127.0.0.1:3000/imgs/TV4S-32.png', '#', 2);
INSERT INTO mi_category VALUES(NULL, '小米盒子', 'http://127.0.0.1:3000/imgs/hezibai480_80.jpg', '#', 2);

INSERT INTO mi_category VALUES(NULL, '小米笔记本 15.6\"', 'http://127.0.0.1:3000/imgs/bijiben80.jpg', '#', 3);
INSERT INTO mi_category VALUES(NULL, '小米笔记本 13.3\"', 'http://127.0.0.1:3000/imgs/80x80.png', '#', 3);
INSERT INTO mi_category VALUES(NULL, '小米笔记本 12.5\"', 'http://127.0.0.1:3000/imgs/bijiben802.jpg', '#', 3);
INSERT INTO mi_category VALUES(NULL, '小米游戏本"', 'http://127.0.0.1:3000/imgs/youxiben-80.jpg', '#', 3);
INSERT INTO mi_category VALUES(NULL, '小米平板4"', 'http://127.0.0.1:3000/imgs/pingban2.jpg', '#', 3);
INSERT INTO mi_category VALUES(NULL, '键盘', 'http://127.0.0.1:3000/imgs/yuemijianpan80.jpg', '#', 3);
INSERT INTO mi_category VALUES(NULL, '鼠标 / 鼠标垫', 'http://127.0.0.1:3000/imgs/wxsb80.png', '#', 3);
INSERT INTO mi_category VALUES(NULL, '转接器', 'http://127.0.0.1:3000/imgs/usbzjqggg80.jpg', '#', 3);
INSERT INTO mi_category VALUES(NULL, '平板配件', 'http://127.0.0.1:3000/imgs/xiaomipingbanpeijian80.jpg', '#', 3);
INSERT INTO mi_category VALUES(NULL, '笔记本双肩包', 'http://127.0.0.1:3000/imgs/bijibenshuangjianbao80.jpg', '#', 3);
INSERT INTO mi_category VALUES(NULL, '小米笔记本内胆包', 'http://127.0.0.1:3000/imgs/neidanbao80.jpg', '#', 3);

INSERT INTO mi_category VALUES(NULL, '米家互联网空调', 'http://127.0.0.1:3000/imgs/kongtiaoguan140.png', '#', 4);
INSERT INTO mi_category VALUES(NULL, '净水器', 'http://127.0.0.1:3000/imgs/jingshuiqi80haha.jpg', '#', 4);
INSERT INTO mi_category VALUES(NULL, '净水器滤芯', 'http://127.0.0.1:3000/imgs/lvxinbashi.png', '#', 4);
INSERT INTO mi_category VALUES(NULL, '扫地机器人', 'http://127.0.0.1:3000/imgs/jiqiren.jpg', '#', 4);
INSERT INTO mi_category VALUES(NULL, '扫地机配件', 'http://127.0.0.1:3000/imgs/saodipeijian-80.jpg', '#', 4);
INSERT INTO mi_category VALUES(NULL, '空气净化器', 'http://127.0.0.1:3000/imgs/jinghuaqi2S-80.jpg', '#', 4);
INSERT INTO mi_category VALUES(NULL, '电饭煲', 'http://127.0.0.1:3000/imgs/yalidianfanbao-80.jpg', '#', 4);
INSERT INTO mi_category VALUES(NULL, '电磁炉', 'http://127.0.0.1:3000/imgs/diancilu-80.jpg', '#', 4);
INSERT INTO mi_category VALUES(NULL, '厨房用具', 'http://127.0.0.1:3000/imgs/tangguo-80.jpg', '#', 4);
INSERT INTO mi_category VALUES(NULL, '电水壶', 'http://127.0.0.1:3000/imgs/dianshuihu-80.jpg', '#', 4);
INSERT INTO mi_category VALUES(NULL, '料理机', 'http://127.0.0.1:3000/imgs/liaoliji80.jpg', '#', 4);
INSERT INTO mi_category VALUES(NULL, '滤水壶', 'http://127.0.0.1:3000/imgs/lvshuihu80.jpg', '#', 4);
INSERT INTO mi_category VALUES(NULL, '落地风扇', 'http://127.0.0.1:3000/imgs/mijiadianfengshan80.png', '#', 4);
INSERT INTO mi_category VALUES(NULL, '投影仪', 'http://127.0.0.1:3000/imgs/touyingyi80.jpg', '#', 4);
INSERT INTO mi_category VALUES(NULL, '灯具', 'http://127.0.0.1:3000/imgs/xidingdeng-80.jpg', '#', 4);
INSERT INTO mi_category VALUES(NULL, '插线板', 'http://127.0.0.1:3000/imgs/chaxianban80.jpg', '#', 4);

INSERT INTO mi_category VALUES(NULL, '手环手表', 'http://127.0.0.1:3000/imgs/go_out/shouhuan3.jpg', '#', 5);
INSERT INTO mi_category VALUES(NULL, 'VR', 'http://127.0.0.1:3000/imgs/go_out/VRyitiji80.jpg', '#', 5);
INSERT INTO mi_category VALUES(NULL, '平衡车', 'http://127.0.0.1:3000/imgs/go_out/scooter-80.jpg', '#', 5);
INSERT INTO mi_category VALUES(NULL, '滑板车', 'http://127.0.0.1:3000/imgs/go_out/scooter2-80.jpg', '#', 5);
INSERT INTO mi_category VALUES(NULL, '自行车', 'http://127.0.0.1:3000/imgs/go_out/zxc80-80.jpg', '#', 5);
INSERT INTO mi_category VALUES(NULL, '车载逆变器', 'http://127.0.0.1:3000/imgs/go_out/chezainibianqi80.jpg', '#', 5);
INSERT INTO mi_category VALUES(NULL, '平衡车配件', 'http://127.0.0.1:3000/imgs/go_out/peijian80.jpg', '#', 5);
INSERT INTO mi_category VALUES(NULL, '智能后视镜', 'http://127.0.0.1:3000/imgs/go_out/mirror-80.jpg', '#', 5);
INSERT INTO mi_category VALUES(NULL, '车载空气净化器', 'http://127.0.0.1:3000/imgs/go_out/chezainibianqi80.jpg', '#', 5);

INSERT INTO mi_category VALUES(NULL, '路由器', 'http://127.0.0.1:3000/imgs/routes/luyouqi4_80.jpg', '#', 6);
INSERT INTO mi_category VALUES(NULL, '对讲机', 'http://127.0.0.1:3000/imgs/routes/duijiangji80.jpg', '#', 6);
INSERT INTO mi_category VALUES(NULL, '智能家庭', 'http://127.0.0.1:3000/imgs/routes/zhinengjiating80.jpg', '#', 6);
INSERT INTO mi_category VALUES(NULL, '无人机', 'http://127.0.0.1:3000/imgs/routes/wurenji80.jpg', '#', 6);
INSERT INTO mi_category VALUES(NULL, '摄像机', 'http://127.0.0.1:3000/imgs/routes/camera-head-80.jpg', '#', 6);
INSERT INTO mi_category VALUES(NULL, '照相机', 'http://127.0.0.1:3000/imgs/routes/camera-small-80.jpg', '#', 6);

INSERT INTO mi_category VALUES(NULL, '移动电源', 'http://127.0.0.1:3000/imgs/parts/dianyuan2.100080.jpg', '#', 7);
INSERT INTO mi_category VALUES(NULL, '数据线', 'http://127.0.0.1:3000/imgs/parts/shujuxian-80.jpg', '#', 7);
INSERT INTO mi_category VALUES(NULL, '车充', 'http://127.0.0.1:3000/imgs/parts/chezaichongdianqi80.jpg', '#', 7);
INSERT INTO mi_category VALUES(NULL, '充电器', 'http://127.0.0.1:3000/imgs/parts/chongdianqi-80.jpg', '#', 7);
INSERT INTO mi_category VALUES(NULL, '无线充', 'http://127.0.0.1:3000/imgs/parts/wuxianchong80.jpg', '#', 7);
INSERT INTO mi_category VALUES(NULL, '自拍杆', 'http://127.0.0.1:3000/imgs/parts/zipaigan80.jpg', '#', 7);
INSERT INTO mi_category VALUES(NULL, '存储卡', 'http://127.0.0.1:3000/imgs/parts/cunchu80x80.jpg', '#', 7);
INSERT INTO mi_category VALUES(NULL, '手机壳', 'http://127.0.0.1:3000/imgs/parts/baohu.jpg', '#', 7);
INSERT INTO mi_category VALUES(NULL, '手机贴膜', 'http://127.0.0.1:3000/imgs/parts/tiemo.jpg', '#', 7);
INSERT INTO mi_category VALUES(NULL, '手机支架', 'http://127.0.0.1:3000/imgs/parts/shoujizhijia80.jpg', '#', 7);
INSERT INTO mi_category VALUES(NULL, '平板配件', 'http://127.0.0.1:3000/imgs/parts/pingban80.jpg', '#', 7);
INSERT INTO mi_category VALUES(NULL, '黑鲨配件', 'http://127.0.0.1:3000/imgs/parts/heishashoubing80.jpg', '#', 7);
INSERT INTO mi_category VALUES(NULL, '其他配件', 'http://127.0.0.1:3000/imgs/parts/qitapeijian80.jpg', '#', 7);

INSERT INTO mi_category VALUES(NULL, '剃须刀', 'http://127.0.0.1:3000/imgs/health/tixvdao80.jpg', '#', 8);
INSERT INTO mi_category VALUES(NULL, '牙刷', 'http://127.0.0.1:3000/imgs/health/yashua80.jpg', '#', 8);
INSERT INTO mi_category VALUES(NULL, '体重秤', 'http://127.0.0.1:3000/imgs/health/scale.jpg', '#', 8);
INSERT INTO mi_category VALUES(NULL, '血压计', 'http://127.0.0.1:3000/imgs/health/xueyaji80.jpg', '#', 8);
INSERT INTO mi_category VALUES(NULL, '体温计', 'http://127.0.0.1:3000/imgs/health/tiwenji80.jpg', '#', 8);
INSERT INTO mi_category VALUES(NULL, '早教启智', 'http://127.0.0.1:3000/imgs/health/mitugushi-80.jpg', '#', 8);
INSERT INTO mi_category VALUES(NULL, '遥控电动', 'http://127.0.0.1:3000/imgs/health/XIAOFEIJIBASHI.jpg', '#', 8);
INSERT INTO mi_category VALUES(NULL, '益智积木', 'http://127.0.0.1:3000/imgs/health/toyblock2-80.jpg', '#', 8);
INSERT INTO mi_category VALUES(NULL, '儿童手表', 'http://127.0.0.1:3000/imgs/health/shoubiao280.jpg', '#', 8);
INSERT INTO mi_category VALUES(NULL, '儿童滑板车', 'http://127.0.0.1:3000/imgs/health/huabanche80.jpg', '#', 8);
INSERT INTO mi_category VALUES(NULL, '儿童书包', 'http://127.0.0.1:3000/imgs/health/ertongshubao.80.jpg', '#', 8);
INSERT INTO mi_category VALUES(NULL, '米兔拉杆箱', 'http://127.0.0.1:3000/imgs/health/laganxiang.jpg', '#', 8);

INSERT INTO mi_category VALUES(NULL, '小爱音箱', 'http://127.0.0.1:3000/imgs/sound/yinxiangmini80.jpg', '#', 9);
INSERT INTO mi_category VALUES(NULL, '线控耳机', 'http://127.0.0.1:3000/imgs/sound/erji80.jpg', '#', 9);
INSERT INTO mi_category VALUES(NULL, '蓝牙耳机', 'http://127.0.0.1:3000/imgs/sound/80xiangquan.jpg', '#', 9);
INSERT INTO mi_category VALUES(NULL, '头戴耳机', 'http://127.0.0.1:3000/imgs/sound/toudai80.jpg', '#', 9);
INSERT INTO mi_category VALUES(NULL, '品牌耳机', 'http://127.0.0.1:3000/imgs/sound/pinpai80.jpg', '#', 9);
INSERT INTO mi_category VALUES(NULL, '蓝牙音箱', 'http://127.0.0.1:3000/imgs/sound/xiaogangpao2-hei-80.jpg', '#', 9);

INSERT INTO mi_category VALUES(NULL, '双肩包', 'http://127.0.0.1:3000/imgs/life/xiangbao-80.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '钱包', 'http://127.0.0.1:3000/imgs/life/qianbao-80.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '口罩', 'http://127.0.0.1:3000/imgs/life/kouzhaofenlei.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '收纳包', 'http://127.0.0.1:3000/imgs/life/shounabao-80.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '旅行箱', 'http://127.0.0.1:3000/imgs/life/lvxingxiang.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '运动鞋', 'http://127.0.0.1:3000/imgs/life/shenhuahui80.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '服饰', 'http://127.0.0.1:3000/imgs/life/txv80.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '眼镜', 'http://127.0.0.1:3000/imgs/life/tyj80.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '床垫', 'http://127.0.0.1:3000/imgs/life/chuangdian-80-80.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '枕头', 'http://127.0.0.1:3000/imgs/life/zhent.ou80.png', '#', 10);
INSERT INTO mi_category VALUES(NULL, '被子', 'http://127.0.0.1:3000/imgs/life/beizi8.0..png', '#', 10);
INSERT INTO mi_category VALUES(NULL, '沙发', 'http://127.0.0.1:3000/imgs/life/shafa.80.png', '#', 10);
INSERT INTO mi_category VALUES(NULL, '针织件套', 'http://127.0.0.1:3000/imgs/life/sijiantao-80-80.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '金米兔', 'http://127.0.0.1:3000/imgs/life/jinmitu.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '螺丝刀', 'http://127.0.0.1:3000/imgs/life/luosidao-80.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '保温杯', 'http://127.0.0.1:3000/imgs/life/bbbbei.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '伞', 'http://127.0.0.1:3000/imgs/life/umbrella.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '驱蚊器', 'http://127.0.0.1:3000/imgs/life/quwenqi.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '尤克里里', 'http://127.0.0.1:3000/imgs/life/ukelele.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '毛巾/浴巾', 'http://127.0.0.1:3000/imgs/life/maojinmaojin.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '米兔', 'http://127.0.0.1:3000/imgs/life/mitu-80.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '签字笔', 'http://127.0.0.1:3000/imgs/life/qianzibi-80.jpg', '#', 10);
INSERT INTO mi_category VALUES(NULL, '笔记本', 'http://127.0.0.1:3000/imgs/life/duoyongbijiben-80.jpg', '#', 10);